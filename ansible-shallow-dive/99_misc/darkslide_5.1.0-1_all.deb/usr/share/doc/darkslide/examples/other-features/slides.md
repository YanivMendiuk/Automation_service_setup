# Other Features: QR

.qr: 450|https://github.com/ionelmc/python-darkslide
